from kivy.app import App                
from kivy.uix.boxlayout import BoxLayout 
from kivy.uix.label import Label         
from kivy.uix.textinput import TextInput 
from kivy.uix.button import Button       


class MeuLayout(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = "vertical"  

       
        self.titulo = Label(
            text="Boas-Vindas",
            font_size=30,
            size_hint=(1, 0.3)  
        )
        self.add_widget(self.titulo)

        
        self.caixa_nome = TextInput(
            hint_text="Digite seu nome aqui...",
            font_size=20,
            size_hint=(1, 0.2)  
        )
        self.add_widget(self.caixa_nome)

        
        self.botao = Button(
            text="Enviar",
            font_size=24,
            background_color=(0, 0.5, 1, 1), 
            size_hint=(1, 0.2)
        )
        self.botao.bind(on_press=self.mostrar_mensagem)
        self.add_widget(self.botao)

       
        self.mensagem = Label(
            text="",
            font_size=22,
            halign="center",   
            valign="middle"    
        )
        self.add_widget(self.mensagem)

    
    def mostrar_mensagem(self, instance):
        nome = self.caixa_nome.text.strip() 
        if nome:  
            self.mensagem.text = f"Bem-vindo(a), {nome}!"
        else: 
            self.mensagem.text = "Por favor, digite seu nome."

class MeuApp(App):
    def build(self):
        return MeuLayout()  

if __name__ == "__main__":
    MeuApp().run()
